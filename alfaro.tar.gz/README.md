NAME: Leonardo Alfaro
CS LOGIN: alfaro
WISC ID: 908 256 5608
EMAIL: lalfaro2@wisc.edu
STATUS: Everything works except MULTIPLE BG AND FG / AFTER BG, DONT RECEIVE SIGNALS
RESOURCES: Use CHATGPT to help writeout the logic of fg and bg